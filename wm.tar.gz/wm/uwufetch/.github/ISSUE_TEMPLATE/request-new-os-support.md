---
name: Request new OS support
about: Request support for a specific OS
title: "[OS-REQUEST]"
labels: ''
assignees: ''

---

**OS info**
- OS name:
- uwufied OS name:
- OS family:
- `/etc/os-release` content:
- if `/etc/os-release` doesn't exist in this OS, alternative way to recognize the OS:
- ascii logo (optional):
- image (optional):

**Additional context**
Add any other context or screenshots about the support request here.
