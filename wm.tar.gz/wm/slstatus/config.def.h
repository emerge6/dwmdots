/* interval between updates (in ms) */
const unsigned int interval = 1000;

/* text to show if no value can be retrieved */
static const char unknown_str[] = "n/a";

/* maximum output string length */
#define MAXLEN 2048

/*
 * function            description                     argument (example)
 *
 * battery_perc        battery percentage              battery name (BAT0)
 * datetime            date and time                   format string (%F %T)
 * kernel_release      `uname -r`                      NULL
 * keymap              layout (variant) of current     NULL
 *                     keymap
 */
static const struct arg args[] = {
    /* function                format           argument */
    { datetime,               "%s",             "%F %T" },
    { keymap,                 " %s ",              NULL },
};

