# makefilesystem/color

`color` Это простая консольная утилита для цветного вывода.

## Сборка
Клонируйте репозиторий и соберите программу.
```bash
git clone https://github.com/makefilesystem/color.git
cd color
sudo make install
```

## Использование

После компиляции можно запустить программу:

```bash
echo "Hello, World!" | color blue --underline
```
